# Contract Analyzer — Doc-to-KB Comparison (Follow-up)

> **Type:** backlog
> **Lane:** OMC (touches `MUFG/contract-analyzer-agent/`, planned in `docs/week_N/{date}/PLANS/`)
> **Observed during:** 2026-05-08 — same evening session that authored `caa-singlestore-bronze-migration/` plan tree
> **Impact:** product-MVP feature; bank-side ask is "compare uploaded contract against a KB of N reference contracts" (1:k), current shape is 1:1
> **Pickup signal:** SingleStore migration plan tree (`docs/week_7/05_08_2026/PLANS/caa-singlestore-bronze-migration/`) reaches `COMPLETE` AND principal greenlights doc-to-KB scoping
> **Disposition:** `observe` — do not execute until prerequisites land

## What

Doc-to-KB comparison feature for Contract Analyzer Agent. User uploads (or links) a knowledge base of N reference contracts; new uploads are compared against the entire KB via top-k retrieval + 1-to-k comparison + aggregation.

## Why this is a follow-up, not a now-item

- Depends on the SingleStore migration landing first. KB collections are inherently multi-document, multi-row, with queryable status; local-fs storage is a poor fit. (See artifact §7.)
- Requires Bedrock embedding access via the AiDa proxy pattern (`Bedrock_calls/embedding_gen.py`); IAM grant for `bedrock:InvokeModel` on the target role is currently blocked (see `MUFG/aida/notes/AIDA_ENTERPRISE_READINESS_NOTES_2026-05-08.md` §3).
- Has its own design questions worth resolving deliberately (ingestion source, vector substrate, aggregation semantics, comparison-mode routing) — see artifact §4.

## Scoping reference

Full pre-plan reference at `docs/week_7/05_08_2026/artifacts/contract-analyzer-doc-to-kb-comparison.md`. That artifact's §4.3 sketches the `CAA_KB_COLLECTION` / `CAA_KB_MEMBER` / `CAA_KB_EMBEDDING` schema; the SingleStore migration plan tree's Step 1 schema is designed to compose with these tables (FK on `CAA_ANALYSIS.ANALYSIS_IDENTIFIER`).

## When to promote

When all four are true:
1. `caa-singlestore-bronze-migration/` plan tree status = `COMPLETE` (Step 9 GREEN).
2. Bedrock IAM grant for the relevant role is live.
3. Principal greenlights doc-to-KB scoping (it has product implications worth confirming).
4. Either Keemin or Erik (MUFG enterprise reviewer) confirms the v1 ingestion-source choice (zip vs. multi-file vs. SharePoint — see artifact §4.2).

At that point, author a new plan tree at `docs/week_N/{date}/PLANS/caa-doc-to-kb-comparison/` per the artifact's §8 entry-point.

## Provenance

- Agent Platform: `unknown`
- Workflow Agent: `oh-my-claudecode:planner`
- Transcript Source: `Unknown`
- Transcript Path: `UNKNOWN`
- Session ID: `a74c80e8e0306633d`
- Ledger File: `.recursor/ledger/2026-05-08.jsonl`
- Note: Backlog stub opened by `caa-singlestore-bronze-migration/` plan-tree authoring pass to surface the dependency relationship.
