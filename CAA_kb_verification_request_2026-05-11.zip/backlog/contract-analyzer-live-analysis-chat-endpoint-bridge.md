# Backlog: Contract Analyzer live analysis/chat endpoint bridge

> **Date:** 05_06_2026
> **Source:** `PLANS/contract-analyzer-production-aida-agent/9_coherence-verification-pass/COHERENCE_VERIFICATION_REPORT.md`
> **Status:** OPEN
> **Owner Gate:** Contract Analyzer implementation follow-up

## Friction

The Contract Analyzer frontend expects live HTTP endpoints for:

- `GET /api/v1/analyses/{analysis_id}/insights`
- `POST /api/v1/analyses/{analysis_id}/chat`

The backend currently exposes upload and health endpoints, while Step 8 proves the internal analysis pipeline and UI rendering separately. This blocks a true local production E2E claim.

## Needed Outcome

Add the live endpoint bridge that loads or derives analysis state from upload/bronze artifacts and returns the existing insight and grounded chat packet contracts.

## Acceptance Signal

- Upload a contract through `POST /api/v1/uploads`.
- Fetch `GET /api/v1/analyses/{analysis_id}/insights` and receive `contract_analyzer_insight_answer_packet_v1` with findings/citations or structured abstention.
- Post `POST /api/v1/analyses/{analysis_id}/chat` and receive `contract_analyzer_grounded_answer_v1` with citations or structured abstention.
- Rerun Step 8 Playwright without mocked API responses.

