# Contract Analyzer — Celery / RQ Background Runtime

> **Type:** backlog
> **Lane:** OMC (touches `MUFG/contract-analyzer-agent/caa_backend/`; introduces a new infra dependency — message broker)
> **Observed during:** 2026-05-08 — RALPLAN consensus pass that authored `caa-doc-to-kb-comparison/` plan tree
> **Impact:** durability upgrade for KB ingestion jobs; v1 uses FastAPI's `BackgroundTasks` (in-process, lost on worker restart); v2 would use Celery / RQ for crash-resume
> **Pickup signal:** worker-restart loss happens often enough at scale to be operationally painful (user complaints about lost ingestions); or KB sizes grow past a threshold where re-uploading is no longer acceptable
> **Disposition:** `observe` — do not execute until pain signal fires

## What

Migrate KB ingestion job orchestration from FastAPI's built-in `BackgroundTasks` (in-process, ephemeral) to a real distributed task queue (Celery or RQ, with Redis or RabbitMQ as broker). Adds crash-resume: if a worker dies mid-ingestion, the job is re-queued and a fresh worker picks it up; the user does not need to re-upload.

## Why this is a follow-up, not a now-item

- v1's `BackgroundTasks` matches AiDa's per-process posture (no message broker, no separate worker pool). It's the smallest viable infra surface that delivers async ingestion.
- Worker restarts during ingestion are uncommon (typical KB ingestion completes in single-digit minutes for v1's expected KB sizes; the deployment-window restart frequency is much lower than the ingestion-completion time).
- v1's mitigation — `KB_INGESTION_STALE_TIMEOUT_MINUTES` sweep at app startup, plus the user-facing "re-upload the zip" UX on failed status — converts the worst-case behavior (eternally-stuck `'ingesting'` row) into a recoverable failure.
- Adding Celery / RQ introduces new infra: message broker (Redis or RabbitMQ), separate worker process pool, deployment-pipeline changes, monitoring surface for queue depth + worker health. None of this is justified until the v1 trade-off becomes operationally painful.

## Scoping reference

- Source plan tree: `docs/week_7/05_08_2026/PLANS/caa-doc-to-kb-comparison/` — Step 6 (`BackgroundTasks` orchestration + worker-restart documentation), Consequences (worker-restart trade-off explicit), `KB_POLICY.md` (Step 12 documents the limitation).
- Pre-plan reference: `docs/week_7/05_08_2026/artifacts/contract-analyzer-doc-to-kb-comparison.md` §4.1 (latency / async discussion; pre-dates the explicit trade-off).

## When to promote

When any of:

1. Operational pain: user-reported "lost ingestion" complaints exceed a threshold (suggested: 3 reports per quarter, or 1 report per week sustained).
2. KB size growth: typical v1 KB ingestions take long enough that worker-restart probability becomes uncomfortable (e.g., KB sizes routinely > 200 docs, ingestion times > 30 min).
3. Cost-justification: separate worker pool is needed regardless (e.g., ingestion CPU starves API requests on the same process); migrating to Celery / RQ at the same time is the cheap version.
4. Principal greenlights the infra investment as enterprise-readiness work.

At promotion time, author a new plan tree at `docs/week_N/{date}/PLANS/caa-celery-rq-background-runtime/` with steps roughly: (a) broker choice (Redis vs RabbitMQ vs SQS; MUFG infra-dependent), (b) Celery / RQ task definitions (port `run_kb_ingestion_job` to a task), (c) worker process deployment (Azure DevOps pipeline changes), (d) monitoring + alerting on queue depth / worker health, (e) crash-resume semantics (idempotent task design; per-member re-attempt logic), (f) test suite covering broker outage + worker crash scenarios, (g) `KB_POLICY.md` update removing the worker-restart limitation note.

## Provenance

- Agent Platform: `unknown`
- Workflow Agent: `oh-my-claudecode:executor`
- Transcript Source: `Unknown`
- Transcript Path: `UNKNOWN`
- Session ID: `a54f65ee6f5ab5985`
- Ledger File: `.recursor/ledger/2026-05-08.jsonl`
- Note: Backlog stub opened by `caa-doc-to-kb-comparison/` plan-tree authoring pass to track the explicit worker-restart trade-off in v1.
