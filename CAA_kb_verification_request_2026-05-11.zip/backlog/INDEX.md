# Contract Analyzer Agent Backlog

> Scope: `MUFG/contract-analyzer-agent/backlog/`
> Role: MUFG-side Contract Analyzer follow-up queue.
> Authority: Navigational only; does not outrank CANON, RECURSOR, plan roots, source artifacts, or MUFG-side evidence.

## Open Items

- `contract-analyzer-live-analysis-chat-endpoint-bridge.md` - Add live `/insights` and `/chat` backend bridge so Contract Analyzer can prove true local production E2E.
- `contract-analyzer-mufg-side-launch-validation.md` - MUFG-side verification path for zipped source package and AiDa marketplace launch proof.
- `contract-analyzer-doc-to-kb-comparison-followup.md` - Doc-to-KB (1:k) comparison feature; depends on `caa-singlestore-bronze-migration/` landing first. Pre-plan reference at `docs/week_7/05_08_2026/artifacts/contract-analyzer-doc-to-kb-comparison.md`.
- `caa-collapse-two-main-py-copies.md` - Collapse the canonical `caa_backend/main.py` and the test-target `contract-analyst-agent-mockup/backend_fastapi/main.py` into a single entrypoint to remove the mirror-on-every-edit cost. Filed during 2026-05-08 logging adoption coherence pass; disposition `observe` until MUFG-side round-trip lands.
- `contract-analyzer-per-node-embedding-upgrade.md` - Upgrade `caa-doc-to-kb-comparison/` Step 7 from per-document embeddings to per-spine-node granularity using the schema reserve (`NODE_IDENTIFIER` nullable, `EMBEDDING_GRANULARITY` enum). No DDL migration required. Disposition `observe`; pick up when v1 retrieval-quality data warrants.
- `contract-analyzer-sharepoint-kb-ingester.md` - Add SharePoint as a KB ingestion source; extract `KbIngester` interface based on what SharePoint actually needs. Disposition `observe`; pick up when SharePoint workstream is greenlit (separate AIC review + Graph API IAM grants).
- `contract-analyzer-kb-sharing-across-users.md` - KB sharing across users / teams as a deliberate future feature; v1 is single-owner per `caa-doc-to-kb-comparison/` Locked Decision 3. Disposition `observe`; pick up when bankers actively request sharing.
- `contract-analyzer-celery-rq-background-runtime.md` - Migrate KB ingestion from FastAPI `BackgroundTasks` to Celery / RQ for crash-resume; v1 accepts re-upload-on-restart trade-off. Disposition `observe`; pick up when worker-restart loss becomes operationally painful.
