# Backlog: Contract Analyzer MUFG-side launch validation

> **Date:** 05_06_2026
> **Source:** `PLANS/contract-analyzer-production-aida-agent/9_coherence-verification-pass/COHERENCE_VERIFICATION_REPORT.md`
> **Status:** OPEN
> **Owner Gate:** MUFG-side AiDa environment validation

## Friction

AiDa marketplace launch cannot be fully proven from the local Starstory environment. Required smoke anchors fail locally on an AiDa dependency/import prerequisite:

- `ModuleNotFoundError: No module named 'mysql'`

## Needed Outcome

After the Contract Analyzer source package is downloaded from the public GitHub mirror and extracted, the MUFG-side agent should run the source-packaged handoff instructions:

- Repo: `https://github.com/keeminlee/contract-analyzer-source-handoff`
- Release: `https://github.com/keeminlee/contract-analyzer-source-handoff/releases/tag/contract-analyzer-d17394c`
- Zip: `https://github.com/keeminlee/contract-analyzer-source-handoff/releases/download/contract-analyzer-d17394c/contract-analyzer-source-handoff-d17394c.zip`

- `handoff/MUFG_SIDE_VERIFICATION.md`
- `handoff/EVIDENCE_RETURN_TEMPLATE.md`
- `handoff/PACKAGE_MANIFEST.md`

## Acceptance Signal

- AiDa marketplace shows Contract Analyzer as live.
- Launch action opens the deployed Contract Analyzer frontend.
- Upload, findings/citations, and chat response work after launch.
- MUFG-side evidence template returns `GREEN`, `YELLOW`, or `BLOCKED` with screenshots/logs.
