# Contract Analyzer — Per-node Embedding Upgrade

> **Type:** backlog
> **Lane:** OMC (touches `MUFG/contract-analyzer-agent/caa_backend/`)
> **Observed during:** 2026-05-08 — RALPLAN consensus pass that authored `caa-doc-to-kb-comparison/` plan tree
> **Impact:** retrieval-quality upgrade; v1 ships per-document embeddings (1 vector per KB doc), v2 will ship per-spine-node (10s-100s of vectors per doc) for clause-level relevance
> **Pickup signal:** retrieval-quality data from v1 production usage shows per-doc embeddings missing clause-level matches; or principal greenlights the upgrade as a quality investment ahead of evidence
> **Disposition:** `observe` — do not execute until v1 ships and either signal fires

## What

Upgrade `caa-doc-to-kb-comparison/` Step 7's per-document embedding generation to per-spine-node granularity. Each KB member doc would be chunked along its spine nodes (already produced by the existing bronze → spine pipeline) and one embedding generated per chunk. Retrieval (`retrieve_top_k`) gains a `granularity` filter parameter to choose between `'doc'` and `'node'` retrieval (or to combine them via a "doc-level top-k filter, then node-level rerank" hybrid).

## Why this is a follow-up, not a now-item

- v1's per-doc embeddings are 10×-100× cheaper than per-node and good-enough for the "find me similar contracts" query shape bankers actually use today.
- Per-node would multiply Bedrock cost and embedding row count by the same factor; this is real money at MUFG scale.
- Schema reserve is already in place: `CAA_KB_EMBEDDING.NODE_IDENTIFIER` is nullable and `EMBEDDING_GRANULARITY` is an enum (`'doc' | 'node'`). **No DDL migration is required for the upgrade.**
- The "evidence first" posture: ship v1, measure retrieval quality with real banker queries, *then* decide if per-node is worth the cost.

## Scoping reference

- Source plan tree: `docs/week_7/05_08_2026/PLANS/caa-doc-to-kb-comparison/` — Step 3 (schema reserve), Step 7 (per-doc adapter), Step 8 (retrieval), ADR (embedding-granularity alternatives).
- Pre-plan reference: `docs/week_7/05_08_2026/artifacts/contract-analyzer-doc-to-kb-comparison.md` §4.1 (embedding-granularity discussion).

## When to promote

When any of:

1. v1 retrieval-quality measurements (e.g., banker satisfaction scores, missed-relevant-clause counts) cross a threshold indicating per-doc is insufficient.
2. Per-node Bedrock cost projections (against measured v1 KB sizes) drop to acceptable levels (Titan-v2 pricing changes, MUFG procurement renegotiation, etc.).
3. Principal greenlights the upgrade as a quality investment ahead of evidence.

At promotion time, author a new plan tree at `docs/week_N/{date}/PLANS/caa-per-node-embedding-upgrade/` with steps roughly: (a) chunking strategy decision (spine nodes vs sliding window vs clause-typed), (b) per-node embedding generation in the background job (Step 7's adapter is reused; schema reserve is populated), (c) retrieval extension (`granularity` filter; optional hybrid retrieval), (d) test suite, (e) `KB_POLICY.md` update.

## Provenance

- Agent Platform: `unknown`
- Workflow Agent: `oh-my-claudecode:executor`
- Transcript Source: `Unknown`
- Transcript Path: `UNKNOWN`
- Session ID: `a54f65ee6f5ab5985`
- Ledger File: `.recursor/ledger/2026-05-08.jsonl`
- Note: Backlog stub opened by `caa-doc-to-kb-comparison/` plan-tree authoring pass to surface the deferred upgrade.
