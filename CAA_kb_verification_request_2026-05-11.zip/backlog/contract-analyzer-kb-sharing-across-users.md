# Contract Analyzer — KB Sharing Across Users / Teams

> **Type:** backlog
> **Lane:** OMC (touches `MUFG/contract-analyzer-agent/caa_backend/`; cross-cuts with MUFG Azure AD group strategy)
> **Observed during:** 2026-05-08 — RALPLAN consensus pass that authored `caa-doc-to-kb-comparison/` plan tree
> **Impact:** product feature; v1 KBs are single-owner (`USER_IDENTIFIER` FK); v2 would add per-collection ACL list, share/revoke surface, team-binding decisions
> **Pickup signal:** bankers actively request sharing (e.g., team-shared playbooks); or principal greenlights as enterprise-readiness feature
> **Disposition:** `observe` — do not execute until product signal warrants

## What

Add KB sharing across users and teams. Today, every KB collection is owned by exactly one user (`CAA_KB_COLLECTION.USER_IDENTIFIER` FK to `claims["pid"]`); cross-user requests return 404 (per Locked Decision 3 + Principle 3 of `caa-doc-to-kb-comparison/`). v2 would introduce per-collection ACL allowing the owner to share read access (or read+ingest access) with named users, named teams, or Azure AD groups.

## Why this is a follow-up, not a now-item

- v1 ships single-owner because that's the cleanest possible ACL story — every read and write checks `pid == row.USER_IDENTIFIER`, no group resolution, no team membership lookup, no share-table joins.
- KB sharing is **a deliberate future feature**, not an accidental one — the v1 schema explicitly does not model sharing, so an accidental cross-user leak is structurally impossible.
- Sharing requires decisions that cut across MUFG's broader Azure AD group strategy (which groups are usable for ACL? how do team boundaries map to AD groups? how do we handle a user leaving a team — share auto-revoke?). These are governance decisions, not just code.
- The right time to scope sharing is when bankers actively request it (or principal explicitly prioritizes it) — not preemptively.

## Scoping reference

- Source plan tree: `docs/week_7/05_08_2026/PLANS/caa-doc-to-kb-comparison/` — Locked Decision 3, Principle 3, Step 3 (schema), Step 4 (CRUD endpoints), Step 12 (`KB_POLICY.md` documents single-owner posture).
- Pre-plan reference: `docs/week_7/05_08_2026/artifacts/contract-analyzer-doc-to-kb-comparison.md` §4.6, §9.3.

## When to promote

When all of:

1. Bankers actively request sharing (e.g., "my team needs access to my GCIB Standard Loan Terms KB"), captured as a real product signal not a hypothetical.
2. MUFG Azure AD group strategy is clear enough to bind ACL surfaces to (which AD groups are stable and usable for application ACL).
3. Principal greenlights the feature scope (read-only sharing vs. read+ingest sharing vs. transfer-of-ownership; team-bound vs. user-bound; revoke semantics).

At promotion time, author a new plan tree at `docs/week_N/{date}/PLANS/caa-kb-sharing-across-users/` with steps roughly: (a) ACL design + schema (`CAA_KB_COLLECTION_SHARE` table or similar), (b) share/revoke endpoints, (c) ACL enforcement updates across all KB read paths, (d) AD-group resolution layer (if team-binding is in scope), (e) audit-log surface for share/revoke events, (f) test suite covering all share permutations, (g) `KB_POLICY.md` update.

## Provenance

- Agent Platform: `unknown`
- Workflow Agent: `oh-my-claudecode:executor`
- Transcript Source: `Unknown`
- Transcript Path: `UNKNOWN`
- Session ID: `a54f65ee6f5ab5985`
- Ledger File: `.recursor/ledger/2026-05-08.jsonl`
- Note: Backlog stub opened by `caa-doc-to-kb-comparison/` plan-tree authoring pass to surface the deferred sharing feature; explicitly NOT a v1 scope.
