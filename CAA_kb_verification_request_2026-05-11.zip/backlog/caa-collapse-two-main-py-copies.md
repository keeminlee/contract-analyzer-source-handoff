# Backlog — Collapse the two CAA `main.py` copies

> **Filed:** 2026-05-08
> **Source:** `docs/week_7/05_08_2026/PLANS/caa-aida-style-logging-adoption/` (Step 10 coherence pass)
> **Type:** code-hygiene / governance friction
> **Lane:** OMC
> **Disposition:** observe — no action required pre-launch; revisit when MUFG-side round-trip lands.

---

## Observation

CAA carries two near-identical FastAPI entrypoints:

- `MUFG/contract-analyzer-agent/caa_backend/main.py` — the canonical/live target (CORS, Azure AD auth dep, insights+chat routes).
- `MUFG/contract-analyzer-agent/contract-analyst-agent-mockup/backend_fastapi/main.py` — the test target (the existing 37-test baseline imports `backend_fastapi.main`).

The 2026-05-08 logging-adoption plan tree (`caa-aida-style-logging-adoption/`) and the SingleStore migration plan tree (`caa-singlestore-bronze-migration/`) both write every code change to **both** files (the canonical, and the mirror). This works but doubles the diff surface and creates drift risk on every future change.

The principal acknowledged this in the executor briefing: *"Strategy: treat `caa_backend\main.py` as canonical. After each step's edits, mirror the relevant changes into `contract-analyst-agent-mockup\backend_fastapi\main.py` so the existing tests exercise the new behavior."* — i.e. mirror is the agreed interim posture.

## Pickup signal

Revisit when **either**:

1. The MUFG-side round-trip workstream (separate from this lane per executor briefing) collapses the mockup directory back into the live `caa_backend/` tree, OR
2. A diff check shows the two files have drifted in any non-mirrored way (any field-name difference between the two `main.py` copies that is not deliberate).

## Suggested action when picked up

1. Move the test suite import root from `backend_fastapi.main` to `caa_backend.main` (or wrap as a shim).
2. Migrate `extraction.py` and the `tools/` package to a single canonical location.
3. Delete `contract-analyst-agent-mockup/backend_fastapi/main.py`.
4. Re-run the now-37+42 = 79-test suite against `caa_backend.main` directly.
5. Update `LOGGING_POLICY.md` "Adding a new route" checklist to drop the "mirror to mockup" step.

## Provenance

- Filed by: `oh-my-claudecode:executor` (Claude Opus 4.7 1M context, OMC lane)
- During: Step 10 coherence pass of `caa-aida-style-logging-adoption/`
- Session ID: `aee7a60465b637641`
