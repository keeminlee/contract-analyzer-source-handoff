# Contract Analyzer — SharePoint KB Ingester

> **Type:** backlog
> **Lane:** OMC (touches `MUFG/contract-analyzer-agent/caa_backend/`; depends on MUFG SharePoint Graph API access)
> **Observed during:** 2026-05-08 — RALPLAN consensus pass that authored `caa-doc-to-kb-comparison/` plan tree
> **Impact:** enterprise-native ingestion source; v1 ships zip-only (`ZipKbIngester`), v2 adds SharePoint folder URL → enumerate + pull → existing bronze pipeline
> **Pickup signal:** SharePoint workstream greenlit (separate AIC review + IAM grant for Graph API on the relevant SharePoint sites); or principal greenlights as enterprise-readiness investment
> **Disposition:** `observe` — do not execute until SharePoint workstream greenlit

## What

Add SharePoint as a KB ingestion source. User pastes a SharePoint folder URL into the CAA UI; backend enumerates the folder via Microsoft Graph API, pulls each document, and runs each through the existing bronze + spine + embedding pipeline (same downstream as `ZipKbIngester`). The `KbIngester` interface that artifact §9.4.5 originally proposed is **extracted in this work**, based on what SharePoint actually needs (delta tokens for incremental sync, folder enumeration, OAuth scope grants, file-type filtering) — not designed against unknown requirements in v1.

## Why this is a follow-up, not a now-item

- Separate workstream with its own AIC review and IAM grants on SharePoint Graph API permissions for the relevant SharePoint sites — not a code-only change.
- v1's zip path delivers the same downstream behavior (extract → embed → retrieve → compare) without blocking on SharePoint plumbing.
- The artifact's original "design `KbIngester` interface in v1 with zip as first impl" framing was deliberately reversed in the consensus pass: v1 ships concrete `ZipKbIngester` with no interface (Locked Decision §9.4.5 controlled re-litigation), and the interface is extracted *based on SharePoint's actual requirements* when this backlog item is picked up. Designing an interface against unknown requirements is more likely wrong than right.

## Scoping reference

- Source plan tree: `docs/week_7/05_08_2026/PLANS/caa-doc-to-kb-comparison/` — Step 5 (`ZipKbIngester` with EXTRACTION POINT comment), Locked Decision 5 (controlled re-litigation), ADR (Ingestion source alternatives).
- Pre-plan reference: `docs/week_7/05_08_2026/artifacts/contract-analyzer-doc-to-kb-comparison.md` §4.2 (SharePoint feasibility note).

## When to promote

When all of:

1. SharePoint Graph API access workstream is greenlit by MUFG enterprise (AIC review + IAM grants on the target SharePoint sites).
2. CAA's deploy environment has the necessary OAuth app registration with the right Graph API scopes.
3. Either Keemin or the MUFG enterprise reviewer (Erik) confirms the v2 ingestion-source rollout is wanted.

At promotion time, author a new plan tree at `docs/week_N/{date}/PLANS/caa-sharepoint-kb-ingester/` with steps roughly: (a) extract `KbIngester` interface from `ZipKbIngester` (refactor commit), (b) implement `SharePointKbIngester` (folder enumeration, file pull, delta-token persistence for incremental sync), (c) UI surface for SharePoint URL paste, (d) test suite (mocked Graph API responses), (e) `KB_POLICY.md` update for SharePoint-specific semantics (e.g., what happens when the SharePoint folder is moved or permissioned-out).

## Provenance

- Agent Platform: `unknown`
- Workflow Agent: `oh-my-claudecode:executor`
- Transcript Source: `Unknown`
- Transcript Path: `UNKNOWN`
- Session ID: `a54f65ee6f5ab5985`
- Ledger File: `.recursor/ledger/2026-05-08.jsonl`
- Note: Backlog stub opened by `caa-doc-to-kb-comparison/` plan-tree authoring pass; references the controlled re-litigation of Locked Decision §9.4.5.
