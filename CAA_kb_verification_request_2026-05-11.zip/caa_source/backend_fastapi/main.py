from __future__ import annotations

import json
import logging
import os
import sys
import time
import uuid
from pathlib import Path
from typing import Any

# Make `caa_backend.storage` importable when running under the mockup tree
# (caa_backend lives one level up, sibling to contract-analyst-agent-mockup).
_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.requests import Request

from backend_fastapi.extraction import (
    EXTRACTION_TIMEOUT_SECONDS,
    MAX_UPLOAD_BYTES,
    BronzeBoundaryError,
    extract_and_store_bronze,
)
from caa_backend.storage import BronzeStore
from tools.contract_insights import analyze_contract_insights
from tools.insight_packet import build_insight_answer_packet
from tools.production_spine import build_spine_from_bronze
from tools.retrieval_evidence import build_evidence_packet
from tools.semantic_router import route_query

# ---------------------------------------------------------------------------
# Central logging — mirrors `caa_backend/main.py` and AiDa's pattern. The
# mockup app is what the existing 37-test suite imports, so the logger
# initialization must live here too. See `LOGGING_POLICY.md`.
# ---------------------------------------------------------------------------
LOG_LEVEL = logging.INFO
LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"

root_logger = logging.getLogger()
if not root_logger.handlers:
    logging.basicConfig(
        level=LOG_LEVEL,
        format=LOG_FORMAT,
        handlers=[logging.StreamHandler(sys.stdout)],
    )
else:
    root_logger.setLevel(LOG_LEVEL)
    formatter = logging.Formatter(LOG_FORMAT)
    for handler in root_logger.handlers:
        handler.setFormatter(formatter)

logger = logging.getLogger(__name__)
logger.info("Central logging initialized at level %s", logging.getLevelName(LOG_LEVEL))


# ---------------------------------------------------------------------------
# Auth dependency — local-dev stub matching `caa_backend/main.py` semantics.
# In CAA proper, `verify_azure_token` validates an Azure AD bearer token via
# JWKS. In the mockup (no JWKS reachable in tests) we honor `CAA_SKIP_AUTH=1`
# as a dev escape and otherwise reject. Tests use FastAPI dependency-overrides
# to inject distinct `claims` dicts (see `app.dependency_overrides`).
# ---------------------------------------------------------------------------
async def verify_azure_token(request: Request) -> dict:
    """FastAPI dependency — mockup-side equivalent of CAA's Azure AD validator.
    Set `CAA_SKIP_AUTH=1` in tests / local dev to bypass."""
    if os.getenv("CAA_SKIP_AUTH") == "1":
        return {"pid": "dev", "roles": [], "groups": []}
    auth_header = request.headers.get("Authorization") or request.headers.get("authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    # The mockup does not contact JWKS; reject anything not bypassed.
    raise HTTPException(status_code=401, detail="Unauthorized")


APP_VERSION = "0.1"
SUPPORTED_EXTENSIONS = (".txt", ".pdf", ".docx")

app = FastAPI(title="contract-analyzer-backend", version=APP_VERSION)


def _resolve_client_ip(request: Request) -> str:
    """IP precedence ladder per AiDa convention (Locked Decision 7):
    `X-Real-IP` -> first hop of `X-Forwarded-For` -> `request.client.host`."""
    real_ip = request.headers.get("X-Real-IP") or request.headers.get("x-real-ip")
    if real_ip:
        return real_ip.strip()
    forwarded = request.headers.get("X-Forwarded-For") or request.headers.get("x-forwarded-for")
    if forwarded:
        first_hop = forwarded.split(",")[0].strip()
        if first_hop:
            return first_hop
    if request.client and request.client.host:
        return request.client.host
    return "unknown"


def _route_template(request: Request) -> str:
    """Return the matched FastAPI path template (e.g. `/api/v1/analyses/{analysis_id}/insights`)
    instead of the interpolated URL. Falls back to raw path when no route matched."""
    route = request.scope.get("route")
    path_template = getattr(route, "path", None)
    if path_template:
        return path_template
    return request.url.path


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """Emit one structured transport-line per request.

    Format (Locked Decision 1, key=value whitespace-separated):
        event=request request_id=<uuid> route=<template> method=<m>
        status=<code> latency_ms=<int> ip=<addr>

    Generates `request_id` server-side as UUID4 hex if no inbound
    `X-Request-ID` header (Locked Decision 2). Echoes the id on the
    response. `/health` logs at DEBUG (suppressed by default INFO
    threshold) to avoid liveness-probe flooding (Locked Decision 8).
    """
    start = time.perf_counter()
    inbound_request_id = (
        request.headers.get("X-Request-ID")
        or request.headers.get("x-request-id")
        or ""
    ).strip()
    request_id = inbound_request_id if inbound_request_id else uuid.uuid4().hex
    request.state.request_id = request_id

    response = await call_next(request)

    latency_ms = int((time.perf_counter() - start) * 1000)
    response.headers["X-Request-ID"] = request_id
    route = _route_template(request)
    ip = _resolve_client_ip(request)
    level = logging.DEBUG if route == "/health" else logging.INFO
    logger.log(
        level,
        "event=request request_id=%s route=%s method=%s status=%d latency_ms=%d ip=%s",
        request_id,
        route,
        request.method,
        response.status_code,
        latency_ms,
        ip,
    )
    return response


app.state.max_upload_bytes = MAX_UPLOAD_BYTES
app.state.extraction_timeout_seconds = EXTRACTION_TIMEOUT_SECONDS


def _error_response(status_code: int, code: str, message: str, *, details: object | None = None) -> JSONResponse:
    payload: dict[str, object] = {
        "error": {
            "code": code,
            "message": message,
        }
    }
    if details is not None:
        payload["error"]["details"] = details
    return JSONResponse(status_code=status_code, content=payload)


@app.exception_handler(RequestValidationError)
async def handle_validation_error(_: Request, exc: RequestValidationError) -> JSONResponse:
    errors = exc.errors()
    for error in errors:
        if error.get("loc") == ("body", "file") and "Expected UploadFile" in str(error.get("msg", "")):
            logger.warning("event=request_invalid status=400 code=empty_filename")
            return _error_response(400, "empty_filename", "Uploaded file must include a filename.")

    logger.warning("event=request_invalid status=422 code=upload_validation_error")
    return _error_response(
        422,
        "upload_validation_error",
        "Upload request is invalid.",
        details=jsonable_encoder(errors),
    )


@app.exception_handler(StarletteHTTPException)
async def handle_http_error(_: Request, exc: StarletteHTTPException) -> JSONResponse:
    if exc.status_code == 400:
        logger.warning("event=request_invalid status=400 code=upload_request_invalid")
        return _error_response(400, "upload_request_invalid", "Upload request body is malformed.")
    logger.warning("event=request_invalid status=%d code=http_error", exc.status_code)
    detail = exc.detail if isinstance(exc.detail, str) else "Request failed."
    return _error_response(exc.status_code, "http_error", detail)


@app.get("/health")
async def health() -> dict[str, str]:
    return {
        "status": "ok",
        "service": "contract-analyzer-backend",
        "version": APP_VERSION,
    }


@app.post("/api/v1/uploads")
async def create_upload(
    request: Request,
    file: UploadFile | None = File(default=None),
    claims: dict = Depends(verify_azure_token),
) -> JSONResponse:
    request.state.pid = claims.get("pid", "unknown")
    request.state.upn = claims.get("upn", "unknown")
    if file is None:
        if request.headers.get("content-length", "0") not in ("", "0"):
            return _error_response(400, "upload_request_invalid", "Upload request body is malformed.")
        return _error_response(422, "missing_upload_file", "Upload file is required.")

    filename = (file.filename or "").strip()
    if not filename:
        return _error_response(400, "empty_filename", "Uploaded file must include a filename.")

    extension = Path(filename).suffix.lower()
    if extension not in SUPPORTED_EXTENSIONS:
        return _error_response(
            400,
            "unsupported_extension",
            "Unsupported file extension.",
            details={"allowed_extensions": list(SUPPORTED_EXTENSIONS), "received_extension": extension},
        )

    content = await file.read()
    if not content:
        return _error_response(400, "empty_upload", "Uploaded file is empty.")

    # Server-assigned UUID v4 hex. Replaces SHA-of-content (Step 3 spec) so
    # two users uploading the same file get distinct analysis_ids.
    analysis_id = uuid.uuid4().hex
    user_identifier = claims.get("pid") or "unknown"
    if user_identifier == "unknown":
        # Defense-in-depth: should never happen if verify_azure_token did its job.
        return _error_response(401, "missing_user_identifier", "User identifier missing from claims.")
    try:
        bronze_result = extract_and_store_bronze(
            filename=filename,
            content=content,
            content_type=file.content_type,
            analysis_id=analysis_id,
            max_upload_bytes=int(app.state.max_upload_bytes),
            extraction_timeout_seconds=int(app.state.extraction_timeout_seconds),
        )
    except BronzeBoundaryError as exc:
        logger.warning(
            "event=upload_failed analysis_id=%s pid=%s request_id=%s code=%s status=%d",
            analysis_id,
            getattr(request.state, "pid", "unknown"),
            getattr(request.state, "request_id", "unknown"),
            exc.code,
            exc.status_code,
        )
        return _error_response(exc.status_code, exc.code, exc.message, details=exc.details)

    # Persist to SingleStore (or in-memory shim) per Step 3.
    store = BronzeStore()
    try:
        store.save_bronze(
            analysis_id=analysis_id,
            user_identifier=user_identifier,
            payload=bronze_result["bronze"],
        )
    finally:
        store.close()

    # Audit line — emitted just before successful return so failed routes
    # (handled by Step 5 boundary-failure logging) do not produce an audit
    # success line. Filename itself is excluded per AC 7.3.
    logger.info(
        "event=upload analysis_id=%s pid=%s upn=%s request_id=%s filename_ext=%s size_bytes=%d",
        analysis_id,
        getattr(request.state, "pid", "unknown"),
        getattr(request.state, "upn", "unknown"),
        getattr(request.state, "request_id", "unknown"),
        extension,
        len(content),
    )
    return JSONResponse(
        status_code=200,
        content={
            "schema_version": "contract_analyzer_upload_v1",
            "analysis_id": analysis_id,
            "session_id": analysis_id,
            "filename": filename,
            "extension": extension,
            "status": "accepted",
            "bronze": bronze_result["bronze"],
            "artifacts": bronze_result["artifact"],
        },
    )


def _load_bronze(store: BronzeStore, analysis_id: str) -> dict[str, Any] | None:
    """Load a bronze record via BronzeStore. Returns None for missing or
    soft-deleted (`ACTIVE_INDICATOR = 0`) rows. Replaces the local-fs read
    path; the local-fs surface is gone after Step 3 of singlestore tree."""
    return store.load_bronze(analysis_id=analysis_id)


def _load_bronze_with_acl(
    store: BronzeStore,
    analysis_id: str,
    pid: str,
) -> tuple[dict[str, Any] | None, JSONResponse | None]:
    """Load + ACL-check. Returns `(bronze, None)` on success, `(None, error)`
    on missing or cross-user. Same `analysis_not_found` envelope for both
    missing and ACL-miss to avoid leaking analysis_id existence (Step 4 spec
    + Locked Decision 10)."""
    bronze = store.load_bronze(analysis_id=analysis_id)
    if bronze is None:
        return None, _error_response(404, "analysis_not_found", f"No analysis found for id: {analysis_id}")
    if bronze.get("user_identifier") != pid:
        return None, _error_response(404, "analysis_not_found", f"No analysis found for id: {analysis_id}")
    return bronze, None


@app.get("/api/v1/analyses/{analysis_id}/insights")
async def get_insights(
    request: Request,
    analysis_id: str,
    baseline_analysis_id: str | None = None,
    claims: dict = Depends(verify_azure_token),
) -> JSONResponse:
    request.state.pid = claims.get("pid", "unknown")
    request.state.upn = claims.get("upn", "unknown")
    pid = request.state.pid
    store = BronzeStore()
    try:
        primary_bronze, err = _load_bronze_with_acl(store, analysis_id, pid)
        if err is not None:
            return err

        primary_spine = build_spine_from_bronze(primary_bronze)

        baseline_spine = None
        if baseline_analysis_id:
            baseline_bronze, baseline_err = _load_bronze_with_acl(store, baseline_analysis_id, pid)
            if baseline_err is not None:
                # Same envelope as primary miss — no info leak (Locked Decision 10).
                return _error_response(404, "baseline_not_found", f"No analysis found for baseline id: {baseline_analysis_id}")
            baseline_spine = build_spine_from_bronze(baseline_bronze)

        analysis = analyze_contract_insights(primary_spine=primary_spine, baseline_spine=baseline_spine)
        packet = build_insight_answer_packet(query="", analysis=analysis)

        logger.info(
            "event=insights_read analysis_id=%s baseline_analysis_id=%s pid=%s upn=%s request_id=%s",
            analysis_id,
            baseline_analysis_id or "none",
            getattr(request.state, "pid", "unknown"),
            getattr(request.state, "upn", "unknown"),
            getattr(request.state, "request_id", "unknown"),
        )
        return JSONResponse(status_code=200, content=packet)
    finally:
        store.close()


@app.delete("/api/v1/analyses/{analysis_id}")
async def delete_analysis(
    request: Request,
    analysis_id: str,
    claims: dict = Depends(verify_azure_token),
) -> JSONResponse:
    """Soft-delete an analysis (flip ACTIVE_INDICATOR to 0).

    ACL: requires `claims["pid"] == row.USER_IDENTIFIER`. Idempotent — a second
    DELETE on the same id returns the same `analysis_not_found` 404 envelope.
    Cross-user delete attempts collapse to the same envelope to avoid leaking
    analysis_id existence (Locked Decision 10).

    v1 does NOT cascade-soft-delete on `CAA_BRONZE_CHUNK`. Chunks remain at
    `ACTIVE_INDICATOR = 1` but are unreachable because their parent analysis
    row is filtered out at read time. Cascade deferred to v2 — see
    `caa_backend/storage.py::soft_delete` docstring.
    """
    request.state.pid = claims.get("pid", "unknown")
    request.state.upn = claims.get("upn", "unknown")
    pid = request.state.pid
    store = BronzeStore()
    try:
        deleted = store.soft_delete(analysis_id=analysis_id, user_identifier=pid)
        if not deleted:
            return _error_response(404, "analysis_not_found", f"No analysis found for id: {analysis_id}")
        logger.info(
            "event=delete analysis_id=%s pid=%s upn=%s request_id=%s",
            analysis_id,
            getattr(request.state, "pid", "unknown"),
            getattr(request.state, "upn", "unknown"),
            getattr(request.state, "request_id", "unknown"),
        )
        return JSONResponse(
            status_code=200,
            content={"status": "deleted", "analysis_id": analysis_id},
        )
    finally:
        store.close()


@app.post("/api/v1/analyses/{analysis_id}/chat")
async def chat(
    request: Request,
    analysis_id: str,
    claims: dict = Depends(verify_azure_token),
) -> JSONResponse:
    request.state.pid = claims.get("pid", "unknown")
    request.state.upn = claims.get("upn", "unknown")
    pid = request.state.pid
    store = BronzeStore()
    try:
        primary_bronze, err = _load_bronze_with_acl(store, analysis_id, pid)
        if err is not None:
            return err

        body = await request.json()
        query = (body.get("query") or "").strip()
        if not query:
            return _error_response(400, "missing_query", "Chat request must include a non-empty query.")

        baseline_analysis_id = body.get("baseline_analysis_id")
        primary_spine = build_spine_from_bronze(primary_bronze)

        baseline_spine = None
        if baseline_analysis_id:
            baseline_bronze, _baseline_err = _load_bronze_with_acl(store, baseline_analysis_id, pid)
            if baseline_bronze:
                baseline_spine = build_spine_from_bronze(baseline_bronze)
            # If baseline is missing or cross-user, silently ignore (preserves
            # existing chat behavior on baseline misses; primary ACL is the
            # binding gate per Locked Decision 10).

        route = route_query(query, comparison_baseline_resolved=baseline_spine is not None)
        evidence_packet = build_evidence_packet(primary_spine, query)
        analysis = analyze_contract_insights(primary_spine=primary_spine, baseline_spine=baseline_spine)
        packet = build_insight_answer_packet(query=query, analysis=analysis)

        logger.info(
            "event=chat analysis_id=%s baseline_analysis_id=%s pid=%s upn=%s request_id=%s query_len=%d query=%r",
            analysis_id,
            baseline_analysis_id or "none",
            getattr(request.state, "pid", "unknown"),
            getattr(request.state, "upn", "unknown"),
            getattr(request.state, "request_id", "unknown"),
            len(query),
            query,
        )
        return JSONResponse(
            status_code=200,
            content={
                "schema_version": "contract_analyzer_chat_response_v1",
                "analysis_id": analysis_id,
                "query": query,
                "route": route.to_dict(),
                "evidence_packet": evidence_packet,
                "answer": packet,
            },
        )
    finally:
        store.close()
