# Evidence Return Template

> Fill this out after MUFG-side verification and return it with screenshots/logs.

---

## Package

- Source package name:
- Source commit or package id:
- Verification date:
- Verifier:
- Environment:

## Environment Versions

```text
python --version:
pip --version:
node --version:
npm --version:
OS/runtime:
AiDa backend branch/commit:
AiDa frontend branch/commit:
Contract Analyzer backend URL:
Contract Analyzer frontend URL:
```

## Product Validation

| Check | Command | Result | Notes / log path |
|-------|---------|--------|------------------|
| Backend tests | `python -m unittest discover -s backend_fastapi/tests -v` |  |  |
| Backend compile | `python -m compileall agents tools backend_fastapi` |  |  |
| Frontend tests | `npm test -- --run` |  |  |
| Frontend build | `npm run build` |  |  |
| Playwright screenshots | `npm run screenshot` |  |  |

## Live Contract Analyzer Endpoint Validation

| Endpoint | Result | Notes / response evidence |
|----------|--------|---------------------------|
| `GET /health` |  |  |
| `POST /api/v1/uploads` |  |  |
| `GET /api/v1/analyses/{analysis_id}/insights` |  |  |
| `POST /api/v1/analyses/{analysis_id}/chat` |  |  |

Observed `analysis_id`:

Evidence citations visible in backend response:

Low/no-evidence behavior observed:

## AiDa Marketplace Validation

| Check | Result | Notes / evidence |
|-------|--------|------------------|
| Manifest test `tests/test_contract_analyzer_marketplace.py` |  |  |
| Contract Analyzer card appears in marketplace |  |  |
| Card status is live |  |  |
| Launch action opens Contract Analyzer frontend |  |  |
| Upload works after marketplace launch |  |  |
| Findings/citations render after launch |  |  |
| Persistent chat returns cited answer or abstention |  |  |

AiDa smoke commands:

| Command | Result | Notes / blocker |
|---------|--------|-----------------|
| `python -m pytest poc/keemin_sse_observability_28_4/sse_smoke_test.py -s` |  |  |
| `python pocs/design5_smoke_test.py` |  |  |

## Screenshots / Attachments

- Marketplace card screenshot:
- Launched Contract Analyzer screenshot:
- Post-upload findings/citations screenshot:
- Chat citation screenshot:
- Logs:

## Blockers

| Blocker | Owner | Exact error | Recommended next action |
|---------|-------|-------------|-------------------------|
|  |  |  |  |

## Final Recommendation

Choose one:

- `GREEN` - Source package and MUFG-side launch validated.
- `YELLOW` - Source package validates, but one or more enterprise integration blockers remain.
- `BLOCKED` - Source package cannot be validated or launch cannot be attempted.

Recommendation:

Rationale:

