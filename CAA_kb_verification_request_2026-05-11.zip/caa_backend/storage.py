"""CAA bronze persistence — SingleStore-backed `BronzeStore`.

Modelled verbatim on AiDa's `MUFG/aida/aid_aida-backend/history/singleStoreHistory.py`
pattern: `__init__ → _load_secrets → _get_connection → close`. Per-request
connection open/close (no pooling — explicit `# TODO(platform-pooling)` marker
mirrors AiDa's known platform-wide tech debt).

Backends
--------
- `singlestore` (default in deployed envs): real SingleStore via `mysql.connector`,
  secrets fetched from AWS Secrets Manager at `/application/aid/{env}/caa-app-secret`.
- `inmemory` (default in tests + local dev without AWS): process-local dict shim.
  Selected via `CAA_STORAGE_BACKEND=inmemory`.

Public methods
--------------
- `save_bronze(*, analysis_id, user_identifier, payload)` — insert one
  CAA_ANALYSIS row + N CAA_BRONZE_CHUNK rows.
- `load_bronze(*, analysis_id)` — return the bronze dict shape that
  `extract_and_store_bronze` returns today, plus `user_identifier`. Returns
  `None` for missing OR soft-deleted rows.
- `soft_delete(*, analysis_id, user_identifier)` — flips ACTIVE_INDICATOR to 0;
  returns True if a row was updated, False otherwise. ACL-enforced at the SQL
  layer (`USER_IDENTIFIER = %s` in WHERE).

NOT persisted in v1 (Locked Decision 1):
- `tables[]` and `metadata` from the bronze payload. Both are passthrough
  surfaces consumed in-process; persisting them would lock the schema to
  AiDa-uninvolved structures.

NOT included (Locked Decision 6):
- Connection pooling. Mirror AiDa's posture; revisit when AiDa adopts a pool.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# In-memory shim state (test seam; Locked Decision 7)
# ---------------------------------------------------------------------------
# Process-global. Resettable via `BronzeStore.reset_inmemory()`. Not a
# long-term abstraction; just a swap point so unit tests + local-dev runs
# without AWS credentials still work.
_inmemory_state: dict[str, dict[str, Any]] = {}


class BronzeStore:
    """Persistence layer for CAA bronze artifacts.

    Per-request lifecycle:
        store = BronzeStore()
        try:
            store.save_bronze(analysis_id=..., user_identifier=..., payload=...)
        finally:
            store.close()
    """

    def __init__(self) -> None:
        self.backend = os.getenv("CAA_STORAGE_BACKEND", "singlestore").strip().lower()
        if self.backend not in ("singlestore", "inmemory"):
            raise ValueError(
                f"CAA_STORAGE_BACKEND must be 'singlestore' or 'inmemory', got {self.backend!r}"
            )
        self.conn = None
        self.cur = None
        if self.backend == "singlestore":
            self.secret_name = (
                f"/application/aid/{os.getenv('CAA_ENV', 'dev').strip()}/caa-app-secret"
            )
            self.region = os.getenv("CAA_AWS_REGION", "us-east-1")
            self.secrets = self._load_secrets()
            # TODO(platform-pooling): mirror AiDa's no-pooling posture; revisit when
            # AiDa adopts a connection pool (per AIDA_ENTERPRISE_READINESS_NOTES_2026-05-08.md).
            self.conn = self._get_connection()
            self.cur = self.conn.cursor(dictionary=True)

    # -- Secrets / connection (verbatim AiDa pattern) ----------------------

    def _load_secrets(self) -> dict:
        # Verbatim AiDa pattern — see `singleStoreHistory.py:_load_secrets`.
        # `verify=False` mirrors AiDa's corporate-proxy posture (readiness §3, §7).
        import boto3  # local import keeps test envs that lack AWS deps importable
        client = boto3.client("secretsmanager", region_name=self.region, verify=False)
        response = client.get_secret_value(SecretId=self.secret_name)
        return json.loads(response["SecretString"])

    def _get_connection(self):
        # Verbatim AiDa pattern — see `singleStoreHistory.py:_get_connection`.
        import mysql.connector  # local import: env may not have driver in inmemory mode
        conn = mysql.connector.connect(
            host=self.secrets["singlestore_host"],
            port=int(self.secrets.get("singlestore_port", 3306)),
            user=self.secrets["singlestore_user"],
            database=self.secrets["singlestore_db"],
            password=self.secrets["singlestore_pwd"],
            allow_local_infile=True,
            use_pure=True,
        )
        return conn

    def close(self) -> None:
        """Close cursor and connection. Safe-no-op in inmemory mode."""
        try:
            if self.cur:
                self.cur.close()
        except Exception:
            pass
        try:
            if self.conn:
                self.conn.close()
        except Exception:
            pass

    # -- Test seam ---------------------------------------------------------

    @staticmethod
    def reset_inmemory() -> None:
        """Clear the inmemory backend state. Intended for tests."""
        _inmemory_state.clear()

    # -- Public CRUD -------------------------------------------------------

    def save_bronze(self, *, analysis_id: str, user_identifier: str, payload: dict) -> str:
        """Insert one CAA_ANALYSIS row + N CAA_BRONZE_CHUNK rows.

        Returns `analysis_id` unchanged. v1 does NOT persist
        `payload["tables"]` or `payload["metadata"]`.
        """
        now = datetime.utcnow()
        source = payload.get("source", {}) or {}
        extracted_text = str(payload.get("extracted_text", ""))
        chunks = payload.get("chunks", []) or []
        schema_version = str(payload.get("schema_version", "contract_analyzer_bronze_v1"))

        if self.backend == "inmemory":
            _inmemory_state[analysis_id] = {
                "analysis_id": analysis_id,
                "user_identifier": user_identifier,
                "schema_version": schema_version,
                "source": dict(source),
                "extracted_text": extracted_text,
                "chunks": [dict(c) for c in chunks],
                "tables": payload.get("tables", []) or [],
                "metadata": dict(payload.get("metadata", {}) or {}),
                "active_indicator": 1,
                "effective_from_timestamp": now,
                "as_of_timestamp": now,
            }
            return analysis_id

        # SingleStore path — parameterized SQL only, no f-string SQL.
        insert_analysis_sql = (
            "INSERT INTO CAA_ANALYSIS ("
            "ANALYSIS_IDENTIFIER, USER_IDENTIFIER, SOURCE_FILENAME, SOURCE_EXTENSION, "
            "SOURCE_MIME_TYPE, SOURCE_SIZE_BYTES, EXTRACTED_TEXT, EXTRACTED_TEXT_CHAR_COUNT, "
            "SCHEMA_VERSION, EFFECTIVE_FROM_TIMESTAMP, ACTIVE_INDICATOR, As_of_Timestamp"
            ") VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        )
        self.cur.execute(
            insert_analysis_sql,
            (
                analysis_id,
                user_identifier,
                source.get("name"),
                source.get("extension"),
                source.get("content_type"),
                source.get("size_bytes"),
                extracted_text,
                len(extracted_text),
                schema_version,
                now,
                1,
                now,
            ),
        )
        self.conn.commit()

        insert_chunk_sql = (
            "INSERT INTO CAA_BRONZE_CHUNK ("
            "CHUNK_IDENTIFIER, ANALYSIS_IDENTIFIER, CHUNK_INDEX, CHUNK_TEXT, "
            "SPAN_START, SPAN_END, EFFECTIVE_FROM_TIMESTAMP, ACTIVE_INDICATOR"
            ") VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
        )
        for index, chunk in enumerate(chunks):
            chunk_id = f"{analysis_id}__{index}"
            self.cur.execute(
                insert_chunk_sql,
                (
                    chunk_id,
                    analysis_id,
                    index,
                    str(chunk.get("text", "")),
                    int(chunk.get("span_start", 0)),
                    int(chunk.get("span_end", 0)),
                    now,
                    1,
                ),
            )
            self.conn.commit()
        return analysis_id

    def load_bronze(self, *, analysis_id: str) -> dict[str, Any] | None:
        """Return the bronze dict (same shape as `extract_and_store_bronze`'s
        output) plus `user_identifier`. Filters `ACTIVE_INDICATOR = 1`.
        Returns `None` for missing OR soft-deleted rows."""
        if self.backend == "inmemory":
            row = _inmemory_state.get(analysis_id)
            if row is None or row.get("active_indicator") != 1:
                return None
            return self._row_to_payload(row, list(row.get("chunks", [])))

        select_analysis_sql = (
            "SELECT ANALYSIS_IDENTIFIER, USER_IDENTIFIER, SOURCE_FILENAME, "
            "SOURCE_EXTENSION, SOURCE_MIME_TYPE, SOURCE_SIZE_BYTES, "
            "EXTRACTED_TEXT, SCHEMA_VERSION, EFFECTIVE_FROM_TIMESTAMP, "
            "ACTIVE_INDICATOR, As_of_Timestamp "
            "FROM CAA_ANALYSIS "
            "WHERE ANALYSIS_IDENTIFIER = %s AND ACTIVE_INDICATOR = 1"
        )
        self.cur.execute(select_analysis_sql, (analysis_id,))
        row = self.cur.fetchone()
        if row is None:
            return None

        select_chunks_sql = (
            "SELECT CHUNK_INDEX, CHUNK_TEXT, SPAN_START, SPAN_END "
            "FROM CAA_BRONZE_CHUNK "
            "WHERE ANALYSIS_IDENTIFIER = %s AND ACTIVE_INDICATOR = 1 "
            "ORDER BY CHUNK_INDEX ASC"
        )
        self.cur.execute(select_chunks_sql, (analysis_id,))
        chunks_rows = self.cur.fetchall() or []
        chunks = [
            {
                "chunk_id": f"bronze_chunk_{int(c['CHUNK_INDEX']) + 1}",
                "text": c["CHUNK_TEXT"],
                "span_start": int(c["SPAN_START"]),
                "span_end": int(c["SPAN_END"]),
            }
            for c in chunks_rows
        ]
        normalized = {
            "analysis_id": row["ANALYSIS_IDENTIFIER"],
            "user_identifier": row["USER_IDENTIFIER"],
            "schema_version": row["SCHEMA_VERSION"],
            "source": {
                "name": row.get("SOURCE_FILENAME"),
                "extension": row.get("SOURCE_EXTENSION"),
                "content_type": row.get("SOURCE_MIME_TYPE"),
                "size_bytes": row.get("SOURCE_SIZE_BYTES"),
            },
            "extracted_text": row.get("EXTRACTED_TEXT") or "",
            "chunks": chunks,
            # v1 does NOT persist tables / metadata; surface empty stand-ins so
            # consumers (build_spine_from_bronze) see a stable shape.
            "tables": [],
            "metadata": {},
        }
        return self._row_to_payload(normalized, chunks)

    def soft_delete(self, *, analysis_id: str, user_identifier: str) -> bool:
        """Flip ACTIVE_INDICATOR to 0 for the named analysis. ACL-enforced at
        the SQL level (`USER_IDENTIFIER = %s` in WHERE) — defense-in-depth.
        Returns True if a row was updated, False otherwise (idempotent miss).
        v1 does NOT cascade-soft-delete on chunks; reads filter through the
        parent analysis's flag."""
        if self.backend == "inmemory":
            row = _inmemory_state.get(analysis_id)
            if row is None or row.get("user_identifier") != user_identifier or row.get("active_indicator") != 1:
                return False
            row["active_indicator"] = 0
            row["as_of_timestamp"] = datetime.utcnow()
            return True

        update_sql = (
            "UPDATE CAA_ANALYSIS SET ACTIVE_INDICATOR = 0, As_of_Timestamp = %s "
            "WHERE ANALYSIS_IDENTIFIER = %s AND USER_IDENTIFIER = %s AND ACTIVE_INDICATOR = 1"
        )
        self.cur.execute(update_sql, (datetime.utcnow(), analysis_id, user_identifier))
        self.conn.commit()
        return self.cur.rowcount > 0

    # -- internals --------------------------------------------------------

    @staticmethod
    def _row_to_payload(row: dict, chunks: list[dict]) -> dict:
        """Shape a row dict into the `extract_and_store_bronze`-compatible
        return so route handlers don't need to know which backend served it."""
        extracted_text = str(row.get("extracted_text", "") or "")
        return {
            "schema_version": row.get("schema_version", "contract_analyzer_bronze_v1"),
            "analysis_id": row.get("analysis_id"),
            "session_id": row.get("analysis_id"),
            "user_identifier": row.get("user_identifier"),
            "source": dict(row.get("source", {}) or {}),
            "text": {
                "full": extracted_text,
                "char_count": len(extracted_text),
            },
            "extracted_text": extracted_text,
            "chunks": list(chunks),
            "tables": list(row.get("tables", []) or []),
            "metadata": dict(row.get("metadata", {}) or {}),
        }
