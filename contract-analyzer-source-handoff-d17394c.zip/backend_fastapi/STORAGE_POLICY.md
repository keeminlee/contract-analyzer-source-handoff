# Contract Analyzer Backend Storage Policy

## V1 Upload Boundary

- Accepted extensions: `.txt`, `.pdf`, `.docx`.
- Maximum upload size: `10 MiB`.
- Extraction timeout: `30 seconds`.
- Virus scanning: out of scope for v1.

## Raw Upload Retention

Raw uploaded document bytes are written only to a per-request temporary file so the existing bronze extractor can read a path with the correct suffix. The temporary file is deleted before the request returns. The backend does not persist raw uploaded documents in v1.

## Bronze Artifact Retention

Successful uploads persist a bronze JSON artifact under `backend_fastapi/runtime/bronze/{analysis_id}/bronze.json`. This runtime directory is git-ignored and is the only retained output from Step 2b.

The bronze artifact contains:

- original source filename, extension, MIME type, and byte size
- extracted text
- chunk records with character spans
- extraction metadata, including timeout and v1 retention policy fields

Deletion and lifecycle management beyond this local runtime artifact directory remain a later production hardening concern. Step 2b does not introduce FileNet, Y71, Asset Locator, or any external ingestion dependency.

## Failure Cleanup

Unsupported, empty, oversized, corrupt, no-text, and timeout failures return structured error JSON and do not write a bronze artifact. Raw temporary upload bytes are not intentionally retained after failure.
